﻿#include <iostream>
#include <cmath>
#include "Angle.h"
#include "Point.h"
using namespace std;

//计算并设置两点间的方位角
void CAM(int LR, Angle froAiz ,Point &k) {
    Angle tem = k.getAngle();
    if (LR == 1) {
        k.setAzimuth(k.L(froAiz, tem));
    }
    else if (LR == 2) {
        k.setAzimuth(k.R(froAiz, tem));
    }
}

//计算待测点XY坐标增量
void delXY(Point &k, Angle froAiz) {
    //将转角转为以度为单位的值
    double deg;
    deg = (double)froAiz.getDegrees() + froAiz.getMinutes() / 60.0 + froAiz.getSeconds() / 3600.0;

    //将deg转为弧度制下的值
    const double PI = 3.1415926535897932384;
    double radians = deg * (PI / 180.0);

    //计算点的xy坐标增量
    k.setDelX(k.getDistance() * cos(radians));
    k.setDelY(k.getDistance() * sin(radians));
}


int main() {
    cout << "ATTENTION!!!\n" << "目前技术仅支持>=1°的角度输入、加减计算等操作\n故角度输入格式为：ddmmss，如1085246即表示108°52'46\"\n\n";

    //设置已知方位角
    Angle aizmuth;
    cout << "请输入已知的方位角：\n";
    cin >> aizmuth;

    int n;
    cout << "请输入需要计算的控制点数：\n";
    cin >> n;

    //设置左/右角传算模式
    int LR;
    cout << "选择左角/右角：\n" << "1.左角\t2.右角\n";
    cin >> LR;
    while (LR != 1 && LR != 2) {
        int tem;
        cout << "输入有误，请重新输入：";
        cin >> tem;
        LR = tem;
    }

    //设置已知点的坐标，转角值
    Point start;
    Angle angle;
    double x;
    double y;
    cout << "设置已知点Y轴坐标：\n";
    cin >> y;
    start.setY(y);
    cout << "设置已知点X轴坐标：\n";
    cin >> x;
    start.setX(x);
    cout << "设置已知边与第一条测量边的转角：\n";
    cin >> angle;
    start.setAngle(angle);
    cout << "您设置的起始点坐标为：" << "(" << start.getX() << "," << start.getY() << ")\t" << "转角为：" << start.getAngle() << endl;

    CAM(LR, aizmuth, start);
    cout << "start的方向角为：" << start.getAzimuth() << endl;

    Point* point = new Point[n + 1];
    point[0] = start;
    cout << "\n\n";

    cout << "\n设置测站点与前一点的距离及转角\n";
    for (int i = 0; i < n; i++) {

        double dTem;
        Angle aTem;

        //输出空行，优化各测站点输入时的视觉体验
        if (i > 1) {
            cout << endl << endl;
        }
        //对测站点进行数据传入
        Point k;
        cout << "k" << i+1 << "距离：";
        cin >> dTem;
        k.setDistance(dTem);
        cout << "k" << i+1 << "转角(输入格式同已知点)：";
        cin >> aTem;
        k.setAngle(aTem);
        cout << "k" << i+1 << "的转角为：" << k.getAngle() << "\t\t\t";

        //计算并设置测站点k的方向角
        Angle tem;
        tem = point[i].getAzimuth();
        CAM(LR, tem, k);
        cout << "k" << i+1 << "的方向角为：" << k.getAzimuth();

        //计算测站点k的坐标增量并输出，方便检查
        delXY(k, tem);
        cout << endl << "delX =  " << k.getDelX() << "\t\tdelY =  " << k.getDelY() << "\n\n";

        //将k传入point中
        point[i + 1] = k;
    }

    //输出点坐标，精度为小数点后两位
    cout << "\n\n\n各点坐标如下：\n";
    for (int j = 1; j <= n; j++) {
        double x;
        double y;

        x = point[j].getDelX() + point[j - 1].getX();
        y = point[j].getDelY() + point[j - 1].getY();

        point[j].setX(x);
        point[j].setY(y);

        cout << fixed << setprecision(2);
        if (j < 4) {
            cout << "k" << j << "(" << point[j].getX() << "," << point[j].getY() << ")\n";
        }
        else {
            cout << "计算所得终点坐标为：" << "(" << point[j].getX() << "," << point[j].getY() << ")\n";
        }

    }

    delete[] point;

    return 0;


}