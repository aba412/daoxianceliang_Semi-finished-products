#pragma once
#ifndef ANGLE_H
#define ANGLE_H

#include <iostream>
using namespace std;

class Angle {
private:
    int data;
    int degrees;
    int minutes;
    int seconds;

public:

    Angle(int angle) {
        data = angle;
        degrees = data / 10000;
        minutes = data / 100 % 100;
        seconds = data % 100;
    }

    Angle() :degrees(0), minutes(0), seconds(0) ,data(0){}

    Angle(const Angle& other) :degrees(other.degrees), minutes(other.minutes), seconds(other.seconds),data(other.seconds) {
    }

    // ���ü���ȡ�Ƕ�
    void setData(int da) {
        data = da;
    }
    int getData() const {
        return data;
    }

    // ���ü���ȡ��
    void setDegrees(int deg) { 
        degrees = deg; 
    }
    int getDegrees() const {
        return degrees; 
    }

    // ���ü���ȡ��
    void setMinutes(int min){
        minutes = min;
    }
    int getMinutes() const {
        return minutes;
    }

    // ���ü���ȡ��
    void setSeconds(int sec) {
        seconds = sec;
    }
    int getSeconds() const {
        return seconds;
    }

    //����"<<"�����
    static friend std::ostream& operator<<(std::ostream& os, const Angle& angle) {
        os << angle.degrees << "�� " << angle.minutes << "' " << angle.seconds << "\"";
        return os;
    }

    //����">>"�����
    static friend std::istream& operator>>(std::istream& is, Angle& angle) {
        is >> angle.data;
        angle.degrees = angle.data / 10000;
        angle.minutes = angle.data / 100 % 100;
        angle.seconds = angle.data % 100;
        return is;
    }

    //�Ƕ����µļӷ�
    Angle operator+(const Angle& other) const {
        int totalSeconds = seconds + other.seconds;
        int carryMinutes = totalSeconds / 60;
        totalSeconds %= 60;

        int totalMinutes = minutes + other.minutes + carryMinutes;
        int carryDegrees = totalMinutes / 60;
        totalMinutes %= 60;

        int totalDegrees = degrees + other.degrees + carryDegrees;

        return Angle(totalDegrees * 10000 + totalMinutes * 100 + totalSeconds);
    }

    //�Ƕ����µļ���
    Angle operator-(const Angle& other) const {
        int totalSeconds = seconds - other.seconds;
        int borrowMinutes = 0;

        if (totalSeconds < 0) {
            totalSeconds += 60;
            borrowMinutes = 1;
        }

        int totalMinutes = minutes - other.minutes - borrowMinutes;
        int borrowDegrees = 0;

        if (totalMinutes < 0) {
            totalMinutes += 60;
            borrowDegrees = 1;
        }

        int totalDegrees = degrees - other.degrees - borrowDegrees;

        return Angle(totalDegrees * 10000 + totalMinutes * 100 + totalSeconds);
    }


};



#endif